import React from "react"
export const Modal = (props) =>{

  const modalInfo = {
    head : "",
    message: "",
    close:""
  }
if(props.status)
{
   modalInfo.head = "Result";
   modalInfo.message = "Author Exists";
   modalInfo.close = "Close";
}
else {

  
  modalInfo.head = "Failure";
  modalInfo.message = "Author Don't Exists";
  modalInfo.close = "Close";


}

console.log(modalInfo);
return(
<div className="modal" tabIndex="-1" role="dialog">
  <div className="modal-dialog" role="document">
    <div className="modal-content">
      <div className="modal-header">
        <h5 className="modal-title">{modalInfo.head}</h5>
        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div className="modal-body">
        <p>{modalInfo.message}</p>
      </div>
      <div className="modal-footer">
        <button type="button" className="btn btn-secondary" data-dismiss="modal">{modalInfo.close}</button>
      </div>
    </div>
  </div>
</div>


);

}
