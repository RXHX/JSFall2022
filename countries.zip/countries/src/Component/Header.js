import React from 'react';
import { NavLink } from 'react-router-dom';


 function Header() {
  return (
    <header>
    <span>
     <ul>
        <li><NavLink  to="/all">All</NavLink></li>
        <li><NavLink  to="/africa">Africa</NavLink></li>
        <li><NavLink  to="/americas">Americas</NavLink></li>
        <li><NavLink  to="/asia">Asia</NavLink></li>
        <li><NavLink  to="/europe">Europe</NavLink></li>
        <li><NavLink  to="/oceania">Oceania</NavLink></li> 
     </ul>
    </span>
    </header>
  );
}
export default Header;
