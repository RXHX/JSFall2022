import React from "react"
export const SearchCard = (props) => {
  
  return(
    <div className="input-group">
  <div className="form-outline">
    <input type="search" id="search" placeholder="Search by Author Name" className="form-control" />
  </div>
  <button type="button" className="btn btn-info"
   
   onClick={() => {
    props.searchQuoteByName(document.getElementById("search").value);
  }}
  
  >Go</button>
</div>
  )


}