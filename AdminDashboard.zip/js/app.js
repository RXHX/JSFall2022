let modal1 = document.getElementById("modal1");
let openModal = () => {
  modal1.classList.toggle("active-modal");
};
let modal2 = document.getElementById("modal2");
let openModal2 = () => {
  modal2.classList.toggle("active-modal");
};
let modal3 = document.getElementById("modal3");
let openModal3 = () => {
  modal3.classList.toggle("active-modal");
};

function addTournament() {
  let tournamentTitle = document.getElementById("tournamentTitle");
  let tournamentDesc = document.getElementById("tournamentDesc");
  if (tournamentTitle.value == "" || tournamentDesc.value == " ") {
    alert("Please fill all the fileds");
  } else {
    let TournamentContainer = document.getElementById("cardContainer");
    let mainDiv = document.createElement("div");
    mainDiv.setAttribute("class", "tournament-card");
    let flexDiv = document.createElement("div");
    flexDiv.setAttribute("class", "flexs");
    let title = document.createElement("h3");
    title.innerHTML = tournamentTitle.value;
    let delContainer = document.createElement("div");
    delContainer.setAttribute("class", "del-modal");
    let Dellbutton = document.createElement("button");
    Dellbutton.setAttribute("onclick", "deleteNode(this)");
    Dellbutton.innerHTML = "Delete";
    delContainer.appendChild(Dellbutton);
    let eclipseDiv = document.createElement("div");
    let eclipseIco = document.createElement("i");
    eclipseIco.setAttribute("class", "fa-solid fa-ellipsis");
    eclipseDiv.setAttribute("class", "opt");
    let description = document.createElement("p");
    description.innerHTML = tournamentDesc.value;
    description.setAttribute("class", "no-margin");

    // input.setAttribute("readonly", "readonly")
    flexDiv.appendChild(title);
    eclipseDiv.appendChild(eclipseIco);
    flexDiv.appendChild(eclipseDiv);
    mainDiv.appendChild(flexDiv);
    flexDiv.appendChild(delContainer);
    mainDiv.appendChild(description);
    TournamentContainer.appendChild(mainDiv);
    console.log(mainDiv);
    modal1.classList.toggle("active-modal");
    tournamentDesc.value = "";
    tournamentTitle.value = "";

    var navItems = document.getElementsByClassName("opt");
    var i;
    for (i = 0; i < navItems.length; i++) {
      navItems[i].addEventListener("click", function () {
        if (!this.classList.contains("active-dels")) {
          clearActives(navItems);
          if (this.classList.contains("active-dels")) {
            this.classList.remove("active-dels");
          } else {
            this.classList.add("active-dels");
          }
        }
      });
    }
    // }

    function clearActives(classlist) {
      if (classlist) {
        for (i = 0; i < classlist.length; i++) {
          classlist[i].classList.remove("active-dels");
        }
      }
    }
  }
}
function addTeam() {
  let tournamentTitle = document.getElementById("tournamentTitle2");
  let tournamentDesc = document.getElementById("tournamentDesc2");
  if (tournamentTitle.value == "" || tournamentDesc.value == " ") {
    alert("Please fill all the fileds");
  } else {
    let TournamentContainer = document.getElementById("cardContainer2");
    let mainDiv = document.createElement("div");
    mainDiv.setAttribute("class", "tournament-card");
    let flexDiv = document.createElement("div");
    flexDiv.setAttribute("class", "flexs");
    let title = document.createElement("h3");
    title.innerHTML = tournamentTitle.value;
    let delContainer = document.createElement("div");
    delContainer.setAttribute("class", "del-modal");
    let Dellbutton = document.createElement("button");
    Dellbutton.setAttribute("onclick", "deleteNode(this)");
    Dellbutton.innerHTML = "Delete";
    delContainer.appendChild(Dellbutton);
    let eclipseDiv = document.createElement("div");
    let eclipseIco = document.createElement("i");
    eclipseIco.setAttribute("class", "fa-solid fa-ellipsis");
    eclipseDiv.setAttribute("class", "opt");
    let description = document.createElement("p");
    description.innerHTML = tournamentDesc.value;
    description.setAttribute("class", "no-margin");

    // input.setAttribute("readonly", "readonly")
    flexDiv.appendChild(title);
    eclipseDiv.appendChild(eclipseIco);
    flexDiv.appendChild(eclipseDiv);
    mainDiv.appendChild(flexDiv);
    flexDiv.appendChild(delContainer);
    mainDiv.appendChild(description);
    TournamentContainer.appendChild(mainDiv);
    console.log(mainDiv);
    modal2.classList.toggle("active-modal");
    tournamentDesc.value = "";
    tournamentTitle.value = "";

    var navItems = document.getElementsByClassName("opt");
    var i;
    for (i = 0; i < navItems.length; i++) {
      navItems[i].addEventListener("click", function () {
        if (!this.classList.contains("active-dels")) {
          clearActives(navItems);
          if (this.classList.contains("active-dels")) {
            this.classList.remove("active-dels");
          } else {
            this.classList.add("active-dels");
          }
        }
      });
    }
    // }

    function clearActives(classlist) {
      if (classlist) {
        for (i = 0; i < classlist.length; i++) {
          classlist[i].classList.remove("active-dels");
        }
      }
    }
  }
}
function addVenue() {
  let tournamentTitle = document.getElementById("tournamentTitle3");
  let tournamentDesc = document.getElementById("tournamentDesc3");
  if (tournamentTitle.value == "" || tournamentDesc.value == " ") {
    alert("Please fill all the fileds");
  } else {
    let TournamentContainer = document.getElementById("cardContainer3");
    let mainDiv = document.createElement("div");
    mainDiv.setAttribute("class", "tournament-card");
    let flexDiv = document.createElement("div");
    flexDiv.setAttribute("class", "flexs");
    let title = document.createElement("h3");
    title.innerHTML = tournamentTitle.value;
    let delContainer = document.createElement("div");
    delContainer.setAttribute("class", "del-modal");
    let Dellbutton = document.createElement("button");
    Dellbutton.setAttribute("onclick", "deleteNode(this)");
    Dellbutton.innerHTML = "Delete";
    delContainer.appendChild(Dellbutton);
    let eclipseDiv = document.createElement("div");
    let eclipseIco = document.createElement("i");
    eclipseIco.setAttribute("class", "fa-solid fa-ellipsis");
    eclipseDiv.setAttribute("class", "opt");
    let description = document.createElement("p");
    description.innerHTML = tournamentDesc.value;
    description.setAttribute("class", "no-margin");

    // input.setAttribute("readonly", "readonly")
    flexDiv.appendChild(title);
    eclipseDiv.appendChild(eclipseIco);
    flexDiv.appendChild(eclipseDiv);
    mainDiv.appendChild(flexDiv);
    flexDiv.appendChild(delContainer);
    mainDiv.appendChild(description);
    TournamentContainer.appendChild(mainDiv);
    console.log(mainDiv);
    modal3.classList.toggle("active-modal");
    tournamentDesc.value = "";
    tournamentTitle.value = "";

    var navItems = document.getElementsByClassName("opt");
    var i;
    for (i = 0; i < navItems.length; i++) {
      navItems[i].addEventListener("click", function () {
        if (!this.classList.contains("active-dels")) {
          clearActives(navItems);
          if (this.classList.contains("active-dels")) {
            this.classList.remove("active-dels");
          } else {
            this.classList.add("active-dels");
          }
        }
      });
    }
    // }

    function clearActives(classlist) {
      if (classlist) {
        for (i = 0; i < classlist.length; i++) {
          classlist[i].classList.remove("active-dels");
        }
      }
    }
  }
}
let deleteNode = (o) => {
  o.parentNode.parentNode.parentNode.remove();
};
var navItems = document.getElementsByClassName("opt");
var i;
for (i = 0; i < navItems.length; i++) {
  navItems[i].addEventListener("click", function () {
    if (!this.classList.contains("active-dels")) {
      clearActives(navItems);
      if (this.classList.contains("active-dels")) {
        this.classList.remove("active-dels");
      } else {
        this.classList.add("active-dels");
      }
    }
  });
}
// }

function clearActives(classlist) {
  if (classlist) {
    for (i = 0; i < classlist.length; i++) {
      classlist[i].classList.remove("active-dels");
    }
  }
}
