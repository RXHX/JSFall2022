import React from "react"
export const DisplayHeading = (props) => {
  return(
    <h1>{props.heading}</h1>
  )


}