import React from 'react';
import '../Styles/styles.css';


export default function Footer() {
  const currentYear = new Date();
  return (
    <footer>
      <p>Generated Today: {currentYear.toString()}</p>
    </footer>
  );
}