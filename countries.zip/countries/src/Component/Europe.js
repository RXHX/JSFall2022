// write your component code here
import React,{useEffect,useState} from 'react';
import axios from 'axios';
import '../Styles/styles.css';
const DisplayEurope = (props) => {
  return(
  <div>

<article className="card" key={props.name}>
            <div className="card-image">
              <img src={props.flag} alt={props.name} />
            </div>
            <div className="card-content">
              <h3 className="card-name">{props.name}</h3>
              <ol className="card-list">
                <li>
                  population: <span>{props.population}</span>
                </li>
                <li>
                  Region: <span>{props.region}</span>
                </li>
                <li>
                  Capital: <span>{props.capital}</span>
                </li>
              </ol>
            </div>
          </article>

  </div>

  )

}
function Europe(props)
{
    const[data,setData] = useState([]);
   
    useEffect(() =>{
     axios.
     get(props.url)
     .then((response) => setData(response.data))
     .catch((e) => console.log("Exception is "+e));
     
    },[]);


    return (
      <>
       <h1>Number Of Countries {data.length}</h1>
       <div className="wrapper">
        <ul className="card-grid">
       {data.map((todo,index) => {
          return <DisplayEurope name={todo.name} key={index} flag = {todo.flag} population={todo.population.toLocaleString("en-US")} region={todo.region} capital={todo.capital}/>;
        })}
     </ul>
        </div>

      </>
    );

}
export default Europe;