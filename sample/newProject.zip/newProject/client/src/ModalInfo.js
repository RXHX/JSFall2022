import React,{useState} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal'
export const ModalInfo = (props) =>{

  const modalInfo = {
    head : "",
    message: "",
    close:""
  }
if(props.status)
{
   modalInfo.head = "Result";
   modalInfo.message = "Author Exists";
   modalInfo.close = "Close";
}
else {

  
  modalInfo.head = "Failure";
  modalInfo.message = "Author Don't Exists";
  modalInfo.close = "Close";
}

const [show, setShow] = useState(true);

  const handleClose = () => setShow(false);


console.log("The status is"+props.status);
console.log("The initial value is"+props.initial);
return(
  <>
 {props.initial ?  <Modal show={show} onHide={handleClose}>
    <Modal.Header closeButton>
      <Modal.Title>{ modalInfo.head }</Modal.Title>
    </Modal.Header>
    <Modal.Body>{ modalInfo.message}</Modal.Body>
    <Modal.Footer>
      <Button variant="secondary" onClick={handleClose}>
        { modalInfo.close}
      </Button>
    </Modal.Footer>
  </Modal>: null}

 
</>

);

}
