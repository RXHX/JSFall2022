import React from 'react';
import {BrowserRouter,Routes,Route } from "react-router-dom";
import All from './Component/All';
import Africa from './Component/Africa';
import Americas from './Component/Americas';
import Asia from './Component/Asia';
import Header from './Component/Header';
import Europe from './Component/Europe';
import Oceania from './Component/Oceania'; 
import Footer from './Component/Footer';
import SubHeader from './Component/SubHeader';






function App() {


   const baseUrl = "https://restcountries.com/v2";

   const continent_Europe = "/region/europe";
   const continent_Asia = "/region/asia";
   const continent_Americas = "/region/americas";
   const continent_Africa = "/region/africa";
   const continent_Oceania = "/region/oceania";
   const continent_All = "/all";

   


 


  return (
    <div> 
    <BrowserRouter>
    <SubHeader/>
    <Header/>
    <Routes>
     <Route path="/all"  element={<All url = {baseUrl+continent_All}/>}/>
     <Route path="/africa"  element={<Africa url = {baseUrl+continent_Africa}/>}/>
     <Route path="/americas"  element={<Americas url = {baseUrl+continent_Americas}/>}/>
     <Route path="/asia"  element={<Asia url ={baseUrl+continent_Asia}/>} />
     <Route path="/europe"  element={<Europe url= {baseUrl+continent_Europe}/>}/> 
     <Route path="/oceania" element={<Oceania url = {baseUrl+continent_Oceania}/>}/>
    </Routes>
    <Footer/>
    </BrowserRouter>      
   </div>
  );
}

export default App;
