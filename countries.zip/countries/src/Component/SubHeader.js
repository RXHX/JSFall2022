import React from 'react';
  function SubHeader()
  {

    return(
      <h1>Awesome Countries Data</h1>
    )

  }
  export default SubHeader;



